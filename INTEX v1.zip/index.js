// Load environment variables from .env file
require('dotenv').config();

const express = require("express");
const app = express();

// Use EJS for the web pages
app.set("view engine", "ejs");

// Serve static files (CSS, images, etc.)
app.use(express.static('public'));

// process.env.PORT is when you deploy and 3000 is for local test
const port = process.env.PORT || 3000;

// Configure database connection (Knex + PostgreSQL) - PLACEHOLDER
const knex = require("knex")({
    client: "pg",
    connection: {
        host: process.env.DB_HOST || "localhost",
        user: process.env.DB_USER || "postgres",
        password: process.env.DB_PASSWORD || "admin",
        database: process.env.DB_NAME || "ella_rises",
        port: process.env.DB_PORT || 5432
    }
});

// Parse form data from POST requests
app.use(express.urlencoded({extended: true}));

// Session support
const session = require('express-session');

// Configure session middleware 
app.use(session({
    secret: process.env.SESSION_SECRET || 'ella-rises-secret',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false } // secure=true requires HTTPS in production
}));

// Make session user available to all views
app.use((req, res, next) => {
    res.locals.currentUser = req.session.user || null;
    next();
});

// ============================================
// ROUTES
// ============================================

// Main landing page
app.get("/", (req, res) => {
    res.render('index');
});

// Login page
app.get('/login', (req, res) => {
    // If already logged in, redirect to dashboard
    if (req.session && req.session.user) {
        return res.redirect('/dashboard');
    }
    res.render('login', { error: null });
});

// Handle login POST
app.post('/login', (req, res) => {
    const email = (req.body.email || '').trim();
    const password = (req.body.password || '').trim();
    
    if (!email || !password) {
        return res.render('login', { error: 'Please provide email and password.' });
    }
    
    // PLACEHOLDER: Database query would go here
    // knex('users').where({ email }).first()
    //     .then(user => {
    //         if (!user || user.password !== password) {
    //             return res.render('login', { error: 'Invalid credentials.' });
    //         }
    //         req.session.user = { id: user.id, email: user.email, name: user.name };
    //         res.redirect('/dashboard');
    //     })
    //     .catch(err => {
    //         console.error('Login error:', err.message);
    //         res.render('login', { error: 'Server error during login.' });
    //     });
    
    // DEMO: Mock authentication
    if (email === 'admin@ellarises.org' && password === 'demo') {
        req.session.user = { id: 1, email: email, name: 'Admin User' };
        res.redirect('/dashboard');
    } else {
        res.render('login', { error: 'Invalid email or password. (Try admin@ellarises.org / demo)' });
    }
});

// Logout
app.get('/logout', (req, res) => {
    req.session.destroy(() => res.redirect('/'));
});

// Dashboard (protected route - requires login)
app.get('/dashboard', (req, res) => {
    if (!req.session.user) {
        return res.redirect('/login');
    }
    res.render('dashboard');
});

// Donations page
app.get('/donate', (req, res) => {
    res.render('donate', { success: null, error: null });
});

// Handle donation form submission
app.post('/donate', (req, res) => {
    const firstName = (req.body.firstName || '').trim();
    const lastName = (req.body.lastName || '').trim();
    const email = (req.body.email || '').trim();
    const phone = (req.body.phone || '').trim();
    const amount = parseFloat(req.body.amount || 0);
    const message = (req.body.message || '').trim();
    
    // Validation
    if (!firstName || !lastName || !email || amount <= 0) {
        return res.render('donate', { 
            success: null, 
            error: 'Please fill in all required fields and enter a valid donation amount.' 
        });
    }
    
    // PLACEHOLDER: Database insert would go here
    // knex('donations').insert({
    //     first_name: firstName,
    //     last_name: lastName,
    //     email: email,
    //     phone: phone,
    //     amount: amount,
    //     message: message,
    //     donation_date: new Date()
    // })
    // .then(() => {
    //     res.render('donate', { 
    //         success: 'Thank you for your generous donation!', 
    //         error: null 
    //     });
    // })
    // .catch(err => {
    //     console.error('Donation error:', err.message);
    //     res.render('donate', { 
    //         success: null, 
    //         error: 'Unable to process donation. Please try again.' 
    //     });
    // });
    
    // DEMO: Mock success
    console.log('DEMO Donation received:', { firstName, lastName, email, amount });
    res.render('donate', { 
        success: `Thank you, ${firstName}! Your donation of $${amount.toFixed(2)} has been received.`, 
        error: null 
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Ella Rises server listening on port ${port}`);
    console.log(`Visit http://localhost:${port}`);
});